<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DevsUnited - Jogo Mosquito </title>
    <link rel="stylesheet" href="estHome.css">
   
</head>
<body>
    
    
    
    <header>
        <a href="" class="logo">DevsUnited</a>
        
        <!--<input type="text" placeholder="pesquise aqui!!!" id="pesquisa" class="pesquisa"> 
        <button id="buscar" class="pesquisabutt">Pesquisar</button>-->
        
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="sobre_nos.php">Sobre Nos</a></li>
            <li><a href="sobre_Jogo.php">Sobre Nosso Jogo</a></li>
            <li><a href="dowjogo.php">Baixar o Jogo Aqui</a></li>
            <li><a href="cadastro.php">Faça seu cadastro</a></li>
            
        </ul>


        <div class="corpo">
            <h1> Seja Bem-Vindo </h1>
                <p>
                    Bem-Vindo ao nosso site nesse site vamos falar um pouco sobre nos, e sobre o nosso jogo que nos mesmos desenvolvemos 
                    ele é um jogo simples mais muito divertido e competitivo para jogar com os amigos.
                </p>
            
                
          </div>
    </header> 




    <img src="fundo2.jpg" class="fundo">
    
    


    
     
    
    
</body>
</html>