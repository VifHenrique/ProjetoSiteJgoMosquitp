<!DOCTYPE html>
<html>
<head>
	<title>Tela de Cadastro</title>
	<link rel="stylesheet" href="estcadastro.css">
</head>
<body>
    

	<header>
		<a href="" class="logo">DevsUnited</a>
		
		<ul>
			<li><a href="home.html">Home</a></li>
			<li><a href="sobre_nos.html">Sobre Nos</a></li>
			<li><a href="sobre_Jogo.html">Sobre Nosso Jogo</a></li>
			<li><a href="dowjogo.html">Baixar o Jogo Aqui</a></li>
			<li><a href="cadastro.html">Faça seu cadastro</a></li>
		</ul>
	</header>
	
	<?php

// Configuração da conexão com o banco de dados
$servername = "localhost";
$username = "seu_nome_de_usuario";
$password = "sua_senha";
$dbname = "nome_do_banco_de_dados";

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica se houve algum erro na conexão
if ($conn->connect_error) {
  die("Falha na conexão: " . $conn->connect_error);
}

// Verifica se o formulário foi enviado
if (isset($_POST['submit'])) {
  
  // Recebe os dados do formulário
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $gender = $_POST['gender'];
  $age = $_POST['age'];
  
  // Inserir os dados no banco de dados
  $sql = "INSERT INTO usuarios (nome, email, senha, genero, idade) 
          VALUES ('$name', '$email', '$password', '$gender', '$age')";

  if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso!";
  } else {
    echo "Erro ao inserir dados: " . $conn->error;
  }
  
  // Fecha a conexão com o banco de dados
  $conn->close();
}

?>

<div  id="conteiner">
	<form method="post">
		<label for="name">Nome:</label>
		<input type="text" id="name" name="name" required>

		<label for="email">Email:</label>
		<input type="email" id="email" name="email" required>

		<label for="password">Senha:</label>
		<input type="password" id="password" name="password" required>

		<label for="gender">Sexo:</label>
		<select id="gender" name="gender" required>
			<option value="">Selecione uma opção</option>
			<option value="male">Masculino</option>
			<option value="female">Feminino</option>
			<option value="other">Outro</option>
		</select>

		<label for="age">Idade:</label>
		<input type="number" id="age" name="age" required>

		<input type="submit" name="submit" value="Cadastrar">
	</form>
</div>
	<img src="fundo2.jpg" class="fundo">
    
    
</body>
</html>
