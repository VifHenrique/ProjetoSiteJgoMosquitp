<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DevsUnited - Jogo Mosquito </title>
    <link rel="stylesheet" href="estSobre.css">
   
</head>
<body>
    
    <img src="mosca.png" id="mosca">
     
    <header>
        
        <a href="" class="logo">DevsUnited</a>
        <!--<input type="text" placeholder="pesquise aqui!!!" id="pesquisa" class="pesquisa"> 
        <button id="buscar" class="pesquisabutt">Pesquisar</button>-->
        
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="sobre_nos.php">Sobre Nos</a></li>
            <li><a href="sobre_Jogo.php">Sobre Nosso Jogo</a></li>
            <li><a href="dowjogo.php">Baixar o Jogo Aqui</a></li>
            <li><a href="cadastro.php">Faça seu cadastro</a></li>
            
        </ul>

        <div class="corpo">
             <h1>
                Um pouco Sobre Nos
             </h1>

            <p>
                Projeto United idealizado por Kauan teve começo dia 06/03/23 , contando com membros altamente capacitados e comprometidos na criação e produção do projeto , a ideia do jogo veio de nosso colega Victor , que sugeriu fazermos um "point and click" e junto disso o insight "Mata Mosquito" , o site foi desenvolvido por Victor e Leonardo Pinheiro , contando com Guilherme na revisão do script. <br><br><br>
            </p>

            <p>
                O Jogo que também foi ideia de Victor , teve a colaboração de Marcos e Leonardo De Freitas e supervisão de Kauan. 
                A Parte documentada do Projeto foi feita por Kauan com Revisão de conteúdo feita por Hyago.
            </p>
        </div>
    </header>
   

    
</body>
</html>